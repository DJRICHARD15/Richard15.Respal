/**
 * 
 */
package com.espe.edu.gestionPagosConstants;

/**
 * @author Admini
 *
 */
public class Constantes {
	
	public static final String DOMAIN1 = "http://localhost:4200";

}
